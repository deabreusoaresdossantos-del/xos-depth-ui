package com.xosdepth.ui

import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { WallpaperScreen() } } }
    }
}

/** Decodifica já no tamanho da tela (economiza RAM) e recorta ao centro. */
private fun loadCropped(ctx: Context, uri: Uri): Bitmap {
    val dm = ctx.resources.displayMetrics
    val w = dm.widthPixels
    val h = dm.heightPixels
    val src = ImageDecoder.createSource(ctx.contentResolver, uri)
    val full = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = maxOf(w.toDouble() / info.size.width, h.toDouble() / info.size.height)
        dec.setTargetSize(
            maxOf(w, Math.ceil(info.size.width * s).toInt()),
            maxOf(h, Math.ceil(info.size.height * s).toInt())
        )
    }
    val out = Bitmap.createBitmap(full, (full.width - w) / 2, (full.height - h) / 2, w, h)
    if (out !== full) full.recycle()
    return out
}

@Composable
private fun WallpaperScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var fg by remember { mutableStateOf<Bitmap?>(null) }
    var composite by remember { mutableStateOf<Bitmap?>(null) }
    var style by remember { mutableStateOf(ClockStyle()) }
    var sizeTmp by remember { mutableFloatStateOf(style.size) }
    var posTmp by remember { mutableFloatStateOf(style.pos) }
    var bake by remember { mutableStateOf(false) }
    var barOn by remember { mutableStateOf(BarListener.enabled(ctx)) }
    var reduce by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val date = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("pt", "BR")))
    }

    LaunchedEffect(bmp, fg, style) {
        val b = bmp ?: return@LaunchedEffect
        composite = withContext(Dispatchers.Default) { composeDepth(b, fg, style) }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.Default) { loadCropped(ctx, uri) } }
                .onSuccess { fg = null; bmp = it; msg = "" }
                .onFailure { msg = ctx.getString(R.string.erro_imagem) }
        }
    }

    fun apply(b: Bitmap?, flag: Int, ok: String) {
        if (b == null) return
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) { WallpaperManager.getInstance(ctx).setBitmap(b, null, true, flag) }
            }.onSuccess { msg = ok }.onFailure { msg = "Não foi possível aplicar: ${it.message}" }
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("XOS Depth UI", style = MaterialTheme.typography.headlineMedium)
        Text("Personalização, vidro e Dynamic Bar (v0.3)", style = MaterialTheme.typography.bodyMedium)

        composite?.let { comp ->
            val img = remember(comp) { comp.asImageBitmap() }
            BoxWithConstraints(
                Modifier.fillMaxWidth(0.7f).aspectRatio(comp.width.toFloat() / comp.height)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(img, "Pré-visualização com profundidade", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                GlassPanel(img, maxWidth, maxHeight, !reduce, Modifier.align(Alignment.BottomCenter)) {
                    Text(date, color = Color.White, modifier = Modifier.align(Alignment.Center))
                }
            }
            Text("O painel de vidro é só um exemplo de widget.", style = MaterialTheme.typography.bodySmall)
        }

        Button(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Escolher imagem da galeria") }

        Button(
            onClick = {
                bmp?.let { b ->
                    busy = true
                    msg = "Separando o primeiro plano..."
                    scope.launch {
                        val r = segmentForeground(b)
                        fg = r
                        msg = if (r != null) "Primeiro plano separado."
                        else "Não foi possível separar. Na primeira vez precisa de internet e dos Serviços do Google Play."
                        busy = false
                    }
                }
            },
            enabled = bmp != null && !busy, modifier = Modifier.fillMaxWidth()
        ) { Text("Separar primeiro plano (profundidade)") }

        Text("Relógio da tela de bloqueio", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CLOCK_FONTS.forEachIndexed { i, f ->
                if (style.font == i) Button(onClick = { style = style.copy(font = i) }) { Text(f.first) }
                else OutlinedButton(onClick = { style = style.copy(font = i) }) { Text(f.first) }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CLOCK_COLORS.forEach { (name, col) ->
                if (style.color == col) Button(onClick = { style = style.copy(color = col) }) { Text(name) }
                else OutlinedButton(onClick = { style = style.copy(color = col) }) { Text(name) }
            }
        }
        Text("Tamanho", style = MaterialTheme.typography.labelLarge)
        Slider(
            value = sizeTmp, onValueChange = { sizeTmp = it },
            onValueChangeFinished = { style = style.copy(size = sizeTmp) }, valueRange = 0.18f..0.34f
        )
        Text("Posição", style = MaterialTheme.typography.labelLarge)
        Slider(
            value = posTmp, onValueChange = { posTmp = it },
            onValueChangeFinished = { style = style.copy(pos = posTmp) }, valueRange = 0.08f..0.45f
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = style.h24, onCheckedChange = { style = style.copy(h24 = it) })
            Spacer(Modifier.width(8.dp)); Text("Formato 24 h")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = style.showDate, onCheckedChange = { style = style.copy(showDate = it) })
            Spacer(Modifier.width(8.dp)); Text("Mostrar data")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = bake, onCheckedChange = { bake = it })
            Spacer(Modifier.width(8.dp)); Text("Embutir relógio na tela de bloqueio")
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = reduce, onCheckedChange = { reduce = it })
            Spacer(Modifier.width(8.dp))
            Text("Reduzir efeitos (sem desfoque)")
        }

        Button(
            onClick = { apply(bmp, WallpaperManager.FLAG_SYSTEM, "Aplicado na tela inicial.") },
            enabled = bmp != null, modifier = Modifier.fillMaxWidth()
        ) { Text("Aplicar na tela inicial") }
        Button(
            onClick = {
                apply(if (bake || fg != null) composite else bmp, WallpaperManager.FLAG_LOCK, "Aplicado na tela de bloqueio.")
            },
            enabled = bmp != null, modifier = Modifier.fillMaxWidth()
        ) { Text("Aplicar na tela de bloqueio") }
        Text(
            "Se o relógio for embutido (ou com profundidade), o relógio do sistema continua aparecendo por cima.",
            style = MaterialTheme.typography.bodySmall
        )

        Text("Widgets", style = MaterialTheme.typography.titleMedium)
        Text(
            "Disponíveis: Relógio, Data grande, Analógico e Bateria (atualiza a cada 30 min). " +
                "Segure em uma área vazia da tela inicial → Widgets → XOS Depth UI.",
            style = MaterialTheme.typography.bodySmall
        )

        Text("Dynamic Bar (estilo XOS 15)", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = barOn, onCheckedChange = { barOn = it; BarListener.setEnabled(ctx, it) })
            Spacer(Modifier.width(8.dp)); Text("Ativar Dynamic Bar")
        }
        OutlinedButton(
            onClick = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }, modifier = Modifier.fillMaxWidth()
        ) { Text("1. Permitir sobrepor outros apps") }
        OutlinedButton(
            onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("2. Permitir acesso às notificações") }
        Button(
            onClick = {
                val b = BarListener.instance
                if (b == null) msg = "Faça os passos 1 e 2 e ative o acesso às notificações primeiro." else b.demo()
            }, modifier = Modifier.fillMaxWidth()
        ) { Text("Testar Dynamic Bar") }
        Text(
            "Se o Android bloquear o passo 2 (configuração restrita): Configurações > Apps > XOS Depth UI > ⋮ > " +
                "Permitir configurações restritas. A barra só mostra app e título; nada é salvo nem enviado.",
            style = MaterialTheme.typography.bodySmall
        )

        OutlinedButton(onClick = {
            runCatching {
                WallpaperManager.getInstance(ctx).clear(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
            }.onSuccess { msg = "Papel de parede padrão do sistema restaurado." }
                .onFailure { msg = "Não foi possível restaurar: ${it.message}" }
        }, modifier = Modifier.fillMaxWidth()) { Text("Restaurar papel de parede padrão") }

        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodyMedium)
    }
}
