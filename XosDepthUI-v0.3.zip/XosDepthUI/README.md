# XOS Depth UI v0.3 (NÃO compilado localmente)
Novidades: fontes/cores/tamanho/posição/24h/data do relógio da tela de bloqueio; widgets Data, Analógico e Bateria;
Dynamic Bar (pílula ao redor da câmera, via acesso a notificações + sobreposição).
Pendente: widget personalizável (cores/transparência), clima, fotos, atalhos, refração AGSL, desempenho/diagnóstico, release.
