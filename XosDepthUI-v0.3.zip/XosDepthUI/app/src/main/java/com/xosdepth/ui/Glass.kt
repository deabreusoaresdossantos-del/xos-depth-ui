package com.xosdepth.ui

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Painel "vidro": desfoque do fundo + tinta + brilho + borda.
 * Deve ficar colado na parte de baixo de um pai com o tamanho parentWidth x parentHeight,
 * cujo fundo é [backdrop]. Sem desfoque (modo reduzido ou Android < 12) usa só tinta escura.
 */
@Composable
fun GlassPanel(
    backdrop: ImageBitmap,
    parentWidth: Dp,
    parentHeight: Dp,
    blurEnabled: Boolean,
    modifier: Modifier = Modifier,
    padding: Dp = 12.dp,
    height: Dp = 72.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(28.dp)
    val doBlur = blurEnabled && Build.VERSION.SDK_INT >= 31
    val rim = Brush.linearGradient(
        listOf(Color.White.copy(alpha = 0.8f), Color.White.copy(alpha = 0.1f), Color.White.copy(alpha = 0.4f))
    )
    Box(
        modifier.padding(padding).fillMaxWidth().height(height).clip(shape).border(1.dp, rim, shape)
    ) {
        if (doBlur) {
            Image(
                backdrop, null,
                modifier = Modifier
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .size(parentWidth, parentHeight)
                    .offset(-padding, -(parentHeight - padding - height))
                    .blur(18.dp),
                contentScale = ContentScale.FillBounds
            )
        }
        Box(
            Modifier.matchParentSize()
                .background(if (doBlur) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.40f))
        )
        Box(
            Modifier.matchParentSize()
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent)))
        )
        content()
    }
}
