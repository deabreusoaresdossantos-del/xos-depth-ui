package com.xosdepth.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Dynamic Bar (inspirada na do XOS 15): pílula preta ao redor da câmera frontal que mostra
 * notificações sem invadir a tela. Só reage a eventos (sem loops) e nada é gravado nem enviado.
 */
class BarListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: BarListener? = null
        fun enabled(ctx: Context) = ctx.getSharedPreferences("bar", Context.MODE_PRIVATE).getBoolean("on", false)
        fun setEnabled(ctx: Context, on: Boolean) =
            ctx.getSharedPreferences("bar", Context.MODE_PRIVATE).edit().putBoolean("on", on).apply()
    }

    private val handler = Handler(Looper.getMainLooper())
    private var box: View? = null
    private var boxLp: WindowManager.LayoutParams? = null
    private val hideRun = Runnable { hide(true) }
    private val power = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { show("Carregador", "conectado") }
    }

    override fun onListenerConnected() {
        instance = this
        val f = IntentFilter(Intent.ACTION_POWER_CONNECTED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(power, f)
    }

    override fun onListenerDisconnected() {
        instance = null
        runCatching { unregisterReceiver(power) }
        hide(false)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!enabled(this) || sbn.packageName == packageName) return
        val n = sbn.notification
        if (sbn.isOngoing || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.visibility == Notification.VISIBILITY_SECRET) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE) ?: return
        val app: CharSequence = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0))
        }.getOrDefault(sbn.packageName)
        handler.post { show(app, title) }
    }

    fun demo() { handler.post { show("XOS Depth UI", "Dynamic Bar funcionando") } }

    private fun show(app: CharSequence, title: CharSequence) {
        if (!enabled(this) || !Settings.canDrawOverlays(this)) return
        hide(false)
        val wm = getSystemService(WindowManager::class.java)
        val dm = resources.displayMetrics
        val d = dm.density
        val h = (38 * d).toInt()
        val startW = (40 * d).toInt()
        val endW = (dm.widthPixels * 0.72f).toInt()
        var top = (6 * d).toInt()
        if (Build.VERSION.SDK_INT >= 30) runCatching {
            wm.currentWindowMetrics.windowInsets.displayCutout?.boundingRects
                ?.firstOrNull { it.top <= 2 }?.let { top = maxOf(0, it.centerY() - h / 2) }
        }
        val tv = TextView(this).apply {
            text = "$app · $title"
            setTextColor(Color.WHITE)
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            alpha = 0f
        }
        val v = LinearLayout(this).apply {
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = h / 2f }
            setPadding((14 * d).toInt(), 0, (14 * d).toInt(), 0)
            addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            setOnClickListener { hide(true) }
        }
        val lp = WindowManager.LayoutParams(
            startW, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = top
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        }
        if (runCatching { wm.addView(v, lp) }.isFailure) return
        box = v
        boxLp = lp
        ValueAnimator.ofInt(startW, endW).apply {
            duration = 350
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener {
                lp.width = it.animatedValue as Int
                tv.alpha = it.animatedFraction.coerceIn(0f, 1f)
                runCatching { wm.updateViewLayout(v, lp) }
            }
            start()
        }
        handler.postDelayed(hideRun, 4000)
    }

    private fun hide(animate: Boolean) {
        handler.removeCallbacks(hideRun)
        val v = box ?: return
        val lp = boxLp
        box = null
        boxLp = null
        val wm = getSystemService(WindowManager::class.java)
        if (!animate || lp == null) {
            runCatching { wm.removeView(v) }
            return
        }
        ValueAnimator.ofInt(lp.width, (40 * resources.displayMetrics.density).toInt()).apply {
            duration = 220
            addUpdateListener {
                lp.width = it.animatedValue as Int
                v.alpha = 1f - it.animatedFraction
                runCatching { wm.updateViewLayout(v, lp) }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { runCatching { wm.removeView(v) } }
            })
            start()
        }
    }
}
