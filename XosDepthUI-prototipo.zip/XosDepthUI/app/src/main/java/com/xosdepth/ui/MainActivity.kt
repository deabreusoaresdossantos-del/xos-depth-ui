package com.xosdepth.ui

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { WallpaperScreen() } } }
    }
}

/** Decodifica já no tamanho da tela (economiza RAM) e recorta ao centro. */
private fun loadCropped(ctx: Context, uri: Uri): Bitmap {
    val dm = ctx.resources.displayMetrics
    val w = dm.widthPixels
    val h = dm.heightPixels
    val src = ImageDecoder.createSource(ctx.contentResolver, uri)
    val full = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = maxOf(w.toDouble() / info.size.width, h.toDouble() / info.size.height)
        dec.setTargetSize(
            maxOf(w, Math.ceil(info.size.width * s).toInt()),
            maxOf(h, Math.ceil(info.size.height * s).toInt())
        )
    }
    val x = (full.width - w) / 2
    val y = (full.height - h) / 2
    val out = Bitmap.createBitmap(full, x, y, w, h)
    if (out !== full) full.recycle()
    return out
}

@Composable
private fun WallpaperScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var msg by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.Default) { loadCropped(ctx, uri) } }
                .onSuccess { bmp = it; msg = "" }
                .onFailure { msg = ctx.getString(R.string.erro_imagem) }
        }
    }

    fun apply(flag: Int, ok: String) {
        val b = bmp ?: return
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    WallpaperManager.getInstance(ctx).setBitmap(b, null, true, flag)
                }
            }.onSuccess { msg = ok }.onFailure { msg = "Não foi possível aplicar: ${it.message}" }
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("XOS Depth UI", style = MaterialTheme.typography.headlineMedium)
        Text("Editor de papel de parede (protótipo)", style = MaterialTheme.typography.bodyMedium)

        bmp?.let {
            Image(
                it.asImageBitmap(), contentDescription = "Pré-visualização do papel de parede",
                modifier = Modifier.fillMaxWidth(0.6f).aspectRatio(it.width.toFloat() / it.height)
                    .clip(MaterialTheme.shapes.large),
                contentScale = ContentScale.Crop
            )
        }

        Button(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Escolher imagem da galeria") }

        val enabled = bmp != null
        Button(
            onClick = { apply(WallpaperManager.FLAG_SYSTEM, "Aplicado na tela inicial.") },
            enabled = enabled, modifier = Modifier.fillMaxWidth()
        ) { Text("Aplicar na tela inicial") }
        Button(
            onClick = { apply(WallpaperManager.FLAG_LOCK, "Aplicado na tela de bloqueio.") },
            enabled = enabled, modifier = Modifier.fillMaxWidth()
        ) { Text("Aplicar na tela de bloqueio") }

        OutlinedButton(onClick = {
            runCatching {
                WallpaperManager.getInstance(ctx).clear(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
            }.onSuccess { msg = "Papel de parede padrão do sistema restaurado." }
                .onFailure { msg = "Não foi possível restaurar: ${it.message}" }
        }, modifier = Modifier.fillMaxWidth()) { Text("Restaurar papel de parede padrão") }

        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodyMedium)

        Text(
            "Widget: segure em uma área vazia da tela inicial do XOS → Widgets → XOS Depth UI.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
