package com.xosdepth.ui

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.BatteryManager
import android.widget.RemoteViews

abstract class LayoutWidget(private val layout: Int) : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, RemoteViews(context.packageName, layout)) }
    }
}

class DateWidget : LayoutWidget(R.layout.widget_date)
class AnalogWidget : LayoutWidget(R.layout.widget_analog)

/** Atualiza no intervalo mínimo do sistema (30 min), sem serviço nem loop. */
class BatteryWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val lvl = context.getSystemService(BatteryManager::class.java)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        ids.forEach {
            val rv = RemoteViews(context.packageName, R.layout.widget_battery)
            rv.setTextViewText(R.id.bat_text, "$lvl%")
            rv.setProgressBar(R.id.bat_bar, 100, lvl, false)
            manager.updateAppWidget(it, rv)
        }
    }
}
