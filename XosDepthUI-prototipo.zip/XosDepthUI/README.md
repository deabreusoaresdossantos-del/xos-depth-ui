# XOS Depth UI — protótipo 0.1 (NÃO compilado nem testado)

## Compilar
1. Android Studio (Koala ou mais novo) → File > Open → pasta XosDepthUI.
2. Aguarde o Gradle Sync (o wrapper e o SDK 34 são baixados pelo próprio Android Studio).
3. Build > Build APK(s) → app/build/outputs/apk/debug/app-debug.apk

## Instalar no Infinix Hot 50i
Copie o APK, abra-o, permita "instalar apps desconhecidos" para o gerenciador de arquivos e instale.
Alternativa: USB + depuração USB ligada → `adb install app-debug.apk`.

## O que o protótipo faz
- Escolhe imagem (seletor de fotos do sistema, sem permissão de armazenamento) e recorta ao centro na proporção da tela.
- Aplica na tela inicial e/ou de bloqueio (WallpaperManager).
- Restaura o papel de parede padrão do sistema.
- Widget de relógio + data (TextClock, sem serviço e sem loop).

## Ainda não implementado
Segmentação/profundidade, recorte manual, DataStore, demais widgets, central de widgets,
tela de desempenho/diagnóstico, APK release assinado.
