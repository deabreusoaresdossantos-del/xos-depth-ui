package com.xosdepth.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.coroutines.resume

/** Separa o primeiro plano (ML Kit, processamento local). Só roda quando o usuário pede. */
suspend fun segmentForeground(src: Bitmap): Bitmap? = suspendCancellableCoroutine { cont ->
    val seg = SubjectSegmentation.getClient(
        SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
    )
    seg.process(InputImage.fromBitmap(src, 0))
        .addOnSuccessListener { seg.close(); cont.resume(it.foregroundBitmap) }
        .addOnFailureListener { seg.close(); cont.resume(null) }
}

data class ClockStyle(
    val font: Int = 2,
    val color: Int = Color.WHITE,
    val size: Float = 0.30f,
    val pos: Float = 0.22f,
    val h24: Boolean = true,
    val showDate: Boolean = true
)

val CLOCK_FONTS: List<Pair<String, Typeface>> = listOf(
    "Fina" to Typeface.create("sans-serif-thin", Typeface.NORMAL),
    "Leve" to Typeface.create("sans-serif-light", Typeface.NORMAL),
    "Normal" to Typeface.create("sans-serif", Typeface.BOLD),
    "Condensada" to Typeface.create("sans-serif-condensed", Typeface.BOLD),
    "Serifada" to Typeface.create("serif", Typeface.BOLD),
    "Mono" to Typeface.create("monospace", Typeface.BOLD),
    "Manuscrita" to Typeface.create("cursive", Typeface.BOLD)
)

val CLOCK_COLORS: List<Pair<String, Int>> = listOf(
    "Branco" to Color.WHITE, "Amarelo" to 0xFFFFE066.toInt(), "Ciano" to 0xFF7FE7FF.toInt(),
    "Rosa" to 0xFFFF8FC7.toInt(), "Verde" to 0xFF9BFFB0.toInt(), "Preto" to Color.BLACK
)

/** Camadas: fundo, relógio (com o estilo escolhido) e, por cima, o primeiro plano. */
fun composeDepth(bg: Bitmap, fg: Bitmap?, st: ClockStyle): Bitmap {
    val out = bg.copy(Bitmap.Config.ARGB_8888, true)
    val c = Canvas(out)
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = st.color
        textAlign = Paint.Align.CENTER
        textSize = out.width * st.size
        typeface = CLOCK_FONTS[st.font.coerceIn(0, CLOCK_FONTS.size - 1)].second
        setShadowLayer(out.width * 0.02f, 0f, 0f, 0x40000000)
    }
    val time = LocalTime.now().format(DateTimeFormatter.ofPattern(if (st.h24) "HH:mm" else "h:mm"))
    val y = out.height * st.pos + p.textSize * 0.35f
    c.drawText(time, out.width / 2f, y, p)
    if (st.showDate) {
        val dp = Paint(p).apply {
            textSize = out.width * 0.05f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val d = LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d 'de' MMM", Locale("pt", "BR")))
        c.drawText(d, out.width / 2f, y + out.width * 0.09f, dp)
    }
    if (fg != null) c.drawBitmap(fg, null, Rect(0, 0, out.width, out.height), null)
    return out
}
